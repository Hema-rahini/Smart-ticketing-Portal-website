import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User, UserRole, Ticket, Message, Channel, Announcement, Department, ActivityItem } from './types'

interface AppState {
  // Auth
  currentUser: User | null
  isAuthenticated: boolean
  selectedRole: UserRole | null
  
  // Data
  users: User[]
  tickets: Ticket[]
  messages: Message[]
  channels: Channel[]
  announcements: Announcement[]
  departments: Department[]
  activities: ActivityItem[]
  
  // UI State
  sidebarOpen: boolean
  currentView: string
  
  // Actions
  setCurrentUser: (user: User | null) => void
  setSelectedRole: (role: UserRole | null) => void
  login: (email: string, password: string, role: UserRole) => boolean
  logout: () => void
  setSidebarOpen: (open: boolean) => void
  setCurrentView: (view: string) => void
  
  // Ticket actions
  createTicket: (ticket: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt'>) => Ticket
  updateTicket: (id: string, updates: Partial<Ticket>) => void
  deleteTicket: (id: string) => void
  
  // Message actions
  sendMessage: (message: Omit<Message, 'id' | 'createdAt'>) => void
  
  // Announcement actions
  createAnnouncement: (announcement: Omit<Announcement, 'id' | 'createdAt'>) => void
  togglePinAnnouncement: (id: string) => void
  reactToAnnouncement: (id: string, emoji: string, userId: string) => void
  
  // User actions
  addUser: (user: Omit<User, 'id' | 'joinedAt'>) => void
  updateUser: (id: string, updates: Partial<User>) => void
}

// Mock data
const mockUsers: User[] = [
  { id: '1', name: 'Admin User', email: 'admin@company.com', role: 'admin', department: 'Management', joinedAt: '2023-01-01', avatar: '' },
  { id: '2', name: 'Sarah Manager', email: 'manager@company.com', role: 'manager', department: 'Engineering', joinedAt: '2023-02-15', managerId: '1' },
  { id: '3', name: 'John Employee', email: 'employee@company.com', role: 'employee', department: 'Engineering', joinedAt: '2023-03-20', managerId: '2' },
  { id: '4', name: 'Alex Intern', email: 'intern@company.com', role: 'intern', department: 'Engineering', joinedAt: '2024-01-10', managerId: '2' },
  { id: '5', name: 'Mike Developer', email: 'mike@company.com', role: 'employee', department: 'Engineering', joinedAt: '2023-04-01', managerId: '2' },
  { id: '6', name: 'Lisa Designer', email: 'lisa@company.com', role: 'employee', department: 'Design', joinedAt: '2023-05-15', managerId: '2' },
  { id: '7', name: 'Tom Intern', email: 'tom@company.com', role: 'intern', department: 'Design', joinedAt: '2024-02-01', managerId: '2' },
]

const mockTickets: Ticket[] = [
  {
    id: 't1',
    title: 'Implement User Authentication',
    description: 'Set up OAuth 2.0 authentication with Google and Microsoft providers.',
    status: 'in-progress',
    priority: 'high',
    createdBy: '3',
    assignedTo: ['3', '5'],
    department: 'Engineering',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-16T14:30:00Z',
    dueDate: '2024-02-01',
    tags: ['auth', 'security'],
    comments: [
      { id: 'c1', content: 'Started working on Google OAuth integration.', authorId: '3', createdAt: '2024-01-15T11:00:00Z' },
      { id: 'c2', content: 'Please also add rate limiting.', authorId: '2', createdAt: '2024-01-15T12:00:00Z' },
    ]
  },
  {
    id: 't2',
    title: 'Design Dashboard UI',
    description: 'Create modern, responsive dashboard UI with analytics widgets.',
    status: 'pending-review',
    priority: 'medium',
    createdBy: '6',
    assignedTo: ['6', '7'],
    department: 'Design',
    createdAt: '2024-01-10T09:00:00Z',
    updatedAt: '2024-01-18T16:00:00Z',
    dueDate: '2024-01-25',
    tags: ['design', 'ui/ux'],
  },
  {
    id: 't3',
    title: 'Fix Performance Issues',
    description: 'Optimize database queries and reduce page load time.',
    status: 'open',
    priority: 'high',
    createdBy: '2',
    assignedTo: ['5'],
    department: 'Engineering',
    createdAt: '2024-01-17T08:00:00Z',
    updatedAt: '2024-01-17T08:00:00Z',
    dueDate: '2024-01-30',
    tags: ['performance', 'optimization'],
  },
  {
    id: 't4',
    title: 'Weekly Report Submission',
    description: 'Submit weekly internship progress report.',
    status: 'completed',
    priority: 'low',
    createdBy: '4',
    assignedTo: ['4'],
    department: 'Engineering',
    createdAt: '2024-01-12T14:00:00Z',
    updatedAt: '2024-01-19T09:00:00Z',
    tags: ['report', 'intern'],
  },
  {
    id: 't5',
    title: 'API Documentation',
    description: 'Write comprehensive API documentation for all endpoints.',
    status: 'in-progress',
    priority: 'medium',
    createdBy: '3',
    assignedTo: ['3'],
    department: 'Engineering',
    createdAt: '2024-01-14T11:00:00Z',
    updatedAt: '2024-01-18T10:00:00Z',
    dueDate: '2024-02-05',
    tags: ['documentation', 'api'],
  },
  {
    id: 't6',
    title: 'Customer Feedback Analysis',
    description: 'Analyze Q4 customer feedback and create improvement recommendations.',
    status: 'open',
    priority: 'medium',
    createdBy: '2',
    assignedTo: ['6'],
    department: 'Design',
    createdAt: '2024-01-16T13:00:00Z',
    updatedAt: '2024-01-16T13:00:00Z',
    dueDate: '2024-02-10',
    tags: ['analysis', 'customer'],
  },
]

const mockAnnouncements: Announcement[] = [
  {
    id: 'a1',
    title: 'Q1 Company Goals',
    content: 'We are excited to announce our Q1 goals! Focus areas include product innovation, customer satisfaction, and team growth. Please review the detailed document shared in your department channels.',
    authorId: '1',
    createdAt: '2024-01-02T09:00:00Z',
    isPinned: true,
    reactions: { '👍': ['2', '3', '4'], '🎯': ['5', '6'] },
  },
  {
    id: 'a2',
    title: 'New Employee Onboarding Session',
    content: 'Welcome to our new team members! There will be an onboarding session next Monday at 10 AM in Conference Room A. All new employees and interns are required to attend.',
    authorId: '1',
    createdAt: '2024-01-15T10:00:00Z',
    isPinned: false,
    reactions: { '👋': ['4', '7'] },
    targetRoles: ['employee', 'intern'],
  },
  {
    id: 'a3',
    title: 'System Maintenance Notice',
    content: 'The ticketing system will undergo scheduled maintenance this Saturday from 2 AM to 6 AM. Please save your work beforehand.',
    authorId: '1',
    createdAt: '2024-01-18T14:00:00Z',
    isPinned: true,
    reactions: { '✅': ['2', '3', '5', '6'] },
  },
]

const mockDepartments: Department[] = [
  { id: 'd1', name: 'Engineering', managerId: '2', memberCount: 4 },
  { id: 'd2', name: 'Design', managerId: '2', memberCount: 2 },
  { id: 'd3', name: 'Management', managerId: '1', memberCount: 1 },
  { id: 'd4', name: 'Marketing', memberCount: 0 },
  { id: 'd5', name: 'Sales', memberCount: 0 },
]

const mockActivities: ActivityItem[] = [
  { id: 'act1', type: 'ticket_created', userId: '3', targetId: 't1', description: 'created ticket "Implement User Authentication"', createdAt: '2024-01-15T10:00:00Z' },
  { id: 'act2', type: 'comment_added', userId: '2', targetId: 't1', description: 'commented on "Implement User Authentication"', createdAt: '2024-01-15T12:00:00Z' },
  { id: 'act3', type: 'status_changed', userId: '6', targetId: 't2', description: 'changed status of "Design Dashboard UI" to Pending Review', createdAt: '2024-01-18T16:00:00Z' },
  { id: 'act4', type: 'ticket_created', userId: '2', targetId: 't3', description: 'created ticket "Fix Performance Issues"', createdAt: '2024-01-17T08:00:00Z' },
  { id: 'act5', type: 'status_changed', userId: '4', targetId: 't4', description: 'completed "Weekly Report Submission"', createdAt: '2024-01-19T09:00:00Z' },
  { id: 'act6', type: 'announcement', userId: '1', targetId: 'a3', description: 'posted announcement "System Maintenance Notice"', createdAt: '2024-01-18T14:00:00Z' },
]

const mockChannels: Channel[] = [
  { id: 'ch1', name: 'Engineering Team', type: 'group', members: ['2', '3', '4', '5'], createdAt: '2024-01-01T00:00:00Z' },
  { id: 'ch2', name: 'Design Team', type: 'group', members: ['2', '6', '7'], createdAt: '2024-01-01T00:00:00Z' },
  { id: 'ch3', name: 'Auth Ticket Discussion', type: 'ticket', members: ['2', '3', '5'], ticketId: 't1', createdAt: '2024-01-15T10:00:00Z' },
]

const mockMessages: Message[] = [
  { id: 'm1', content: 'Hey team, let\'s sync up on the auth implementation.', senderId: '2', channelId: 'ch1', createdAt: '2024-01-15T10:30:00Z' },
  { id: 'm2', content: 'Sounds good! I\'ll prepare the OAuth flow diagrams.', senderId: '3', channelId: 'ch1', createdAt: '2024-01-15T10:35:00Z' },
  { id: 'm3', content: 'Great work on the dashboard designs!', senderId: '2', channelId: 'ch2', createdAt: '2024-01-18T16:30:00Z' },
]

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      currentUser: null,
      isAuthenticated: false,
      selectedRole: null,
      users: mockUsers,
      tickets: mockTickets,
      messages: mockMessages,
      channels: mockChannels,
      announcements: mockAnnouncements,
      departments: mockDepartments,
      activities: mockActivities,
      sidebarOpen: true,
      currentView: 'dashboard',

      // Auth actions
      setCurrentUser: (user) => set({ currentUser: user, isAuthenticated: !!user }),
      setSelectedRole: (role) => set({ selectedRole: role }),
      
      login: (email, password, role) => {
        const user = get().users.find(u => u.email === email && u.role === role)
        if (user) {
          set({ currentUser: user, isAuthenticated: true, selectedRole: role })
          return true
        }
        // For demo, allow any email/password with selected role
        const demoUser: User = {
          id: `demo-${Date.now()}`,
          name: email.split('@')[0].replace(/[.]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
          email,
          role,
          department: 'General',
          joinedAt: new Date().toISOString(),
        }
        set({ currentUser: demoUser, isAuthenticated: true, selectedRole: role })
        return true
      },
      
      logout: () => set({ currentUser: null, isAuthenticated: false, selectedRole: null }),
      
      // UI actions
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setCurrentView: (view) => set({ currentView: view }),

      // Ticket actions
      createTicket: (ticketData) => {
        const newTicket: Ticket = {
          ...ticketData,
          id: `t${Date.now()}`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }
        set((state) => ({
          tickets: [...state.tickets, newTicket],
          activities: [
            {
              id: `act${Date.now()}`,
              type: 'ticket_created',
              userId: ticketData.createdBy,
              targetId: newTicket.id,
              description: `created ticket "${ticketData.title}"`,
              createdAt: new Date().toISOString(),
            },
            ...state.activities,
          ],
        }))
        return newTicket
      },
      
      updateTicket: (id, updates) => {
        set((state) => ({
          tickets: state.tickets.map((t) =>
            t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t
          ),
        }))
      },
      
      deleteTicket: (id) => {
        set((state) => ({
          tickets: state.tickets.filter((t) => t.id !== id),
        }))
      },

      // Message actions
      sendMessage: (messageData) => {
        const newMessage: Message = {
          ...messageData,
          id: `m${Date.now()}`,
          createdAt: new Date().toISOString(),
        }
        set((state) => ({ messages: [...state.messages, newMessage] }))
      },

      // Announcement actions
      createAnnouncement: (announcementData) => {
        const newAnnouncement: Announcement = {
          ...announcementData,
          id: `a${Date.now()}`,
          createdAt: new Date().toISOString(),
        }
        set((state) => ({
          announcements: [newAnnouncement, ...state.announcements],
          activities: [
            {
              id: `act${Date.now()}`,
              type: 'announcement',
              userId: announcementData.authorId,
              targetId: newAnnouncement.id,
              description: `posted announcement "${announcementData.title}"`,
              createdAt: new Date().toISOString(),
            },
            ...state.activities,
          ],
        }))
      },
      
      togglePinAnnouncement: (id) => {
        set((state) => ({
          announcements: state.announcements.map((a) =>
            a.id === id ? { ...a, isPinned: !a.isPinned } : a
          ),
        }))
      },
      
      reactToAnnouncement: (id, emoji, userId) => {
        set((state) => ({
          announcements: state.announcements.map((a) => {
            if (a.id !== id) return a
            const reactions = { ...a.reactions }
            if (!reactions[emoji]) {
              reactions[emoji] = [userId]
            } else if (reactions[emoji].includes(userId)) {
              reactions[emoji] = reactions[emoji].filter((u) => u !== userId)
              if (reactions[emoji].length === 0) delete reactions[emoji]
            } else {
              reactions[emoji] = [...reactions[emoji], userId]
            }
            return { ...a, reactions }
          }),
        }))
      },

      // User actions
      addUser: (userData) => {
        const newUser: User = {
          ...userData,
          id: `u${Date.now()}`,
          joinedAt: new Date().toISOString(),
        }
        set((state) => ({ users: [...state.users, newUser] }))
      },
      
      updateUser: (id, updates) => {
        set((state) => ({
          users: state.users.map((u) => (u.id === id ? { ...u, ...updates } : u)),
        }))
      },
    }),
    {
      name: 'smart-ticketing-storage',
      partialize: (state) => ({
        currentUser: state.currentUser,
        isAuthenticated: state.isAuthenticated,
        selectedRole: state.selectedRole,
      }),
    }
  )
)

// Selector hooks for better performance
export const useCurrentUser = () => useStore((state) => state.currentUser)
export const useIsAuthenticated = () => useStore((state) => state.isAuthenticated)
export const useTickets = () => useStore((state) => state.tickets)
export const useUsers = () => useStore((state) => state.users)
export const useAnnouncements = () => useStore((state) => state.announcements)
export const useActivities = () => useStore((state) => state.activities)
export const useDepartments = () => useStore((state) => state.departments)
export const useChannels = () => useStore((state) => state.channels)
export const useMessages = () => useStore((state) => state.messages)
