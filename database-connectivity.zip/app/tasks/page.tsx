'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useStore } from '@/lib/store'
import { DashboardLayout } from '@/components/layout/dashboard-layout'
import { TicketList } from '@/components/tickets/ticket-list'

export default function TasksPage() {
  const router = useRouter()
  const { isAuthenticated, currentUser } = useStore()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    }
  }, [isAuthenticated, router])

  if (!currentUser) return null

  return (
    <DashboardLayout title="My Tasks">
      <TicketList
        title="My Tasks"
        filter={{
          assignedTo: currentUser.id,
        }}
      />
    </DashboardLayout>
  )
}
